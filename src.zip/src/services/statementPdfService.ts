
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import QRCode from "qrcode";
import { generateAccountStatement, AccountStatementData } from "@/lib/accountStatementExport";

/**
 * Load logo as base64 (Reused from invoicePdfService principle)
 */
async function loadLogoBase64(): Promise<string | null> {
    try {
        const logoModule = await import("@/assets/images/longtime-logo.png");
        if (typeof logoModule.default === "string") {
            return logoModule.default;
        }
        return null;
    } catch (error) {
        console.error("Failed to load logo:", error);
        return null;
    }
}

/**
 * Generate QR Code
 */
async function generateQRCode(text: string = "https://longtimelt.com"): Promise<string> {
    try {
        return await QRCode.toDataURL(text);
    } catch (error) {
        console.error("Error generating QR code:", error);
        return "";
    }
}

/**
 * Format number in English locale
 */
const formatNum = (num: number, minDecimals = 0, maxDecimals = 2) => {
    return (num || 0).toLocaleString("en-US", {
        minimumFractionDigits: minDecimals,
        maximumFractionDigits: maxDecimals
    });
};

/**
 * Generate HTML for Account Statement
 */
export async function generateStatementHTML(data: AccountStatementData): Promise<string> {
    const logoBase64 = await loadLogoBase64();
    const qrCodeBase64 = await generateQRCode();

    const rowsHtml = data.rows.map((row, index) => `
        <tr>
            <td style="width: 25%; text-align: right; padding-right: 5px;">${row.notes || "-"}</td>
            <td style="width: 15%">${formatNum(row.balance, 2, 2)}</td>
            <td style="width: 10%">${row.credit > 0 ? formatNum(row.credit, 2, 2) : "-"}</td>
            <td style="width: 10%">${row.debit > 0 ? formatNum(row.debit, 2, 2) : "-"}</td>
            <td style="width: 15%">${row.movementId || "-"}</td>
            <td style="width: 10%">${row.movement}</td>
            <td style="width: 10%">${row.date}</td>
            <td style="width: 5%">${index + 1}</td>
        </tr>
    `).join("");

    return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>كشف حساب ${data.customer.name}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
        
        @page {
            size: A4;
            margin: 0;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        
        body {
            font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
            direction: rtl;
            background: #fff;
            color: #000;
            width: 210mm;
            min-height: 297mm;
            margin: 0 auto;
            position: relative;
        }
        
        .container {
            padding: 15mm;
        }
        
        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }
        
        .company-header {
            text-align: right;
            padding-top: 10px;
        }
        
        .company-header h1 {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        
        .header-line {
            height: 3px;
            background: #2d5a6b;
            width: 100%;
        }
        
        .logo-container {
            width: 140px;
        }
        
        .logo {
            width: 100%;
            height: auto;
        }
        
        /* Meta Box */
        .meta-box {
            background: #f0f4f8;
            border-right: 4px solid #2d5a6b;
            padding: 10px 15px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .customer-name {
            font-size: 16px;
            font-weight: 700;
        }
        
        .period-info {
            font-size: 12px;
            color: #555;
            font-weight: 600;
        }
        
        /* Summary Cards */
        .summary-cards {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
        }
        
        .card {
            flex: 1;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 8px;
            text-align: center;
        }
        
        .card-title {
            font-size: 11px;
            color: #666;
            margin-bottom: 4px;
        }
        
        .card-value {
            font-size: 14px;
            font-weight: 700;
            color: #2d5a6b;
        }
        
        .card.final {
            background: #2d5a6b;
            color: white;
            border-color: #2d5a6b;
        }
        
        .card.final .card-title {
            color: #eee;
        }
        
        .card.final .card-value {
            color: white;
        }
        
        /* Table */
        .table-container {
            margin-bottom: 30px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
        }
        
        th {
            background: #2d5a6b;
            color: white;
            padding: 8px 4px;
            text-align: center;
            border: 1px solid #fff;
        }
        
        td {
            padding: 6px 4px;
            border: 1px solid #ccc;
            text-align: center;
        }
        
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        
        /* Footer */
        .footer {
            margin-top: auto;
            border-top: 2px solid #eee;
            padding-top: 15px;
            text-align: center;
        }
        
        .site-url {
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .qr img {
            width: 80px;
            height: 80px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="company-header">
                <h1>لونج تايم للصناعات الكهربائية</h1>
                <div class="header-line"></div>
                <div style="font-size: 14px; margin-top: 5px; font-weight: 600;">كشف حساب عميل</div>
            </div>
            <div class="logo-container">
                ${logoBase64 ? `<img src="${logoBase64}" class="logo">` : ''}
            </div>
        </div>

        <!-- Customer Info -->
        <div class="meta-box">
            <div>
                <div style="font-size: 10px; color: #666;">السادة /</div>
                <div class="customer-name">${data.customer.name}</div>
            </div>
            <div class="period-info">
                من: ${data.dateFrom.toLocaleDateString('en-CA')} <br>
                إلى: ${data.dateTo.toLocaleDateString('en-CA')}
            </div>
        </div>
        
        <!-- Opening Balance -->
        <div style="margin-bottom: 10px; font-size: 12px; font-weight: 600;">
            الرصيد الافتتاحي: ${formatNum(data.openingBalance)}
        </div>

        <!-- Table -->
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ملاحظات</th>
                        <th>الرصيد</th>
                        <th> له / دائن (سداد)</th>
                        <th> عليه / مدين (سحب)</th>
                        <th>رقم الحركة</th>
                        <th>نوع الحركة</th>
                        <th>التاريخ</th>
                        <th>م</th>
                    </tr>
                </thead>
                <tbody>
                    ${rowsHtml}
                </tbody>
            </table>
        </div>
        
        <!-- Summary Cards -->
        <div class="summary-cards">
            <div class="card">
                <div class="card-title">إجمالي المبيعات</div>
                <div class="card-value">${formatNum(data.summary.totalSales)}</div>
            </div>
            <div class="card">
                <div class="card-title">إجمالي المرتجعات</div>
                <div class="card-value">${formatNum(data.summary.totalReturns)}</div>
            </div>
            <div class="card">
                <div class="card-title">إجمالي الدفعات</div>
                <div class="card-value">${formatNum(data.summary.totalPayments)}</div>
            </div>
            <div class="card final">
                <div class="card-title">الرصيد النهائي المستحق</div>
                <div class="card-value">${formatNum(data.closingBalance)}</div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <div class="site-url">longtimelt.com</div>
            <div class="qr">
                ${qrCodeBase64 ? `<img src="${qrCodeBase64}">` : ''}
            </div>
        </div>
    </div>
</body>
</html>
    `;
}

/**
 * Generate PDF Blob
 */
export async function generateStatementPDF(customerId: string, from: Date, to: Date): Promise<Blob | null> {
    const data = await generateAccountStatement(customerId, from, to);
    if (!data) return null;

    const html = await generateStatementHTML(data);

    // Create temporary container
    const container = document.createElement("div");
    container.innerHTML = html;
    container.style.position = "absolute";
    container.style.left = "-9999px";
    container.style.width = "210mm"; // A4 width
    document.body.appendChild(container);

    try {
        const canvas = await html2canvas(container, {
            scale: 2, // High resolution
            useCORS: true,
            logging: false,
            windowWidth: 794, // A4 width in px at 96 DPI
        });

        const imgData = canvas.toDataURL("image/jpeg", 0.95);
        const pdf = new jsPDF("p", "mm", "a4");
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

        pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight);
        return pdf.output("blob");
    } catch (error) {
        console.error("PDF Generation Error:", error);
        return null;
    } finally {
        document.body.removeChild(container);
    }
}

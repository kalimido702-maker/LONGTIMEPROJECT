import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import QRCode from "qrcode";

/**
 * Invoice data interface
 */
export interface InvoicePDFData {
    id: string;
    invoiceNumber: string;
    date: string;
    customerName: string;
    salesRepName?: string;
    items: InvoiceItemData[];
    total: number;
    previousBalance?: number;
    currentBalance?: number;
}

export interface InvoiceItemData {
    productName: string;
    productCode?: string;
    quantity: number;
    price: number;
    total: number;
    unitsPerCarton?: number;
}

/**
 * Load logo as base64
 */
async function loadLogoBase64(): Promise<string | null> {
    try {
        const logoModule = await import("@/assets/images/longtime-logo.png");
        if (typeof logoModule.default === "string") {
            return logoModule.default;
        }
        return null;
    } catch (error) {
        console.error("Failed to load logo:", error);
        return null;
    }
}

/**
 * Generate QR code as base64
 */
async function generateQRCode(): Promise<string | null> {
    try {
        return await QRCode.toDataURL("https://longtimelt.com", {
            width: 150,
            margin: 1,
            color: {
                dark: "#000000",
                light: "#ffffff",
            },
        });
    } catch (error) {
        console.error("Failed to generate QR code:", error);
        return null;
    }
}

/**
 * Generate Long Time Invoice as HTML (for proper Arabic support)
 */
export async function generateInvoiceHTML(data: InvoicePDFData): Promise<string> {
    const logoBase64 = await loadLogoBase64();
    const qrCodeBase64 = await generateQRCode();

    // Helper for English number formatting
    const formatNum = (num: number, minDecimals = 0, maxDecimals = 2) => {
        return (num || 0).toLocaleString("en-US", {
            minimumFractionDigits: minDecimals,
            maximumFractionDigits: maxDecimals
        });
    };

    const itemsRows = data.items.map((item, index) => `
        <tr>
            <td style="width: 10%; font-weight: bold;">${item.unitsPerCarton ? formatNum(item.unitsPerCarton, 0, 0) : "-"}</td>
            <td style="width: 15%">${formatNum(item.total, 2, 2)}</td>
            <td style="width: 10%">${formatNum(item.price, 2, 2)}</td>
            <td style="width: 10%">
                <div style="display: flex; justify-content: center; gap: 4px;">
                   <span>${formatNum(item.quantity, 0, 0)}</span>
                   <span style="font-size: 9px; color: #666; margin-top: 2px;">قطعة</span>
                </div>
            </td>
            <td style="width: 15%; font-size: 11px;">${item.productCode || "-"}</td>
            <td style="width: 35%; text-align: right; padding-right: 5px; font-weight: bold;">${item.productName || "-"}</td>
            <td style="width: 5%">${index + 1}</td>
        </tr>
    `).join("");

    return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فاتورة رقم ${data.invoiceNumber}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
        
        @page {
            size: A4;
            margin: 0;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        
        body {
            font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
            direction: rtl;
            background: #fff;
            color: #000;
            width: 210mm;
            min-height: 297mm;
            margin: 0 auto;
            position: relative;
        }
        
        .invoice-container {
            padding: 15mm;
        }
        
        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }
        
        .logo-container {
            width: 140px;
        }
        
        .logo {
            width: 100%;
            height: auto;
        }
        
        .company-header {
            text-align: right;
            padding-top: 10px;
        }
        
        .company-header h1 {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        
        .header-line {
            height: 3px;
            background: #2d5a6b;
            width: 100%;
        }
        
        /* Meta Table */
        .meta-table-container {
            position: absolute;
            left: 15mm;
            top: 45mm;
        }
        
        .meta-table {
            border-collapse: collapse;
            width: 220px;
            text-align: center;
        }
        
        .meta-table th {
            background: #2d5a6b;
            color: white;
            padding: 6px;
            font-size: 11px;
            font-weight: bold;
            border: 1px solid #fff;
        }
        
        .meta-table td {
            background: #fff;
            padding: 6px;
            font-size: 13px;
            border: 1px solid #2d5a6b; 
            font-weight: 700;
        }
        
        /* Customer Section */
        .customer-section {
            margin-top: 60px;
            margin-bottom: 25px;
            text-align: right;
        }
        
        .bill-to-tag {
            background: #2d5a6b;
            color: white;
            display: inline-block;
            padding: 4px 20px 4px 10px;
            font-size: 10px;
            border-radius: 4px 0 0 4px;
            margin-bottom: 8px;
            position: relative;
            right: -15mm;
        }
        
        .customer-name {
            font-size: 18px;
            font-weight: 800;
            color: #000;
            margin-bottom: 4px;
        }
        
        .customer-sub {
            font-size: 13px;
            color: #555;
            font-weight: 600;
        }
        
        /* Items Table */
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
        }
        
        .items-table th {
            background: #2d5a6b;
            color: white;
            padding: 10px 5px;
            font-size: 11px;
            border: 1px solid #fff;
            text-align: center;
            font-weight: 700;
        }
        
        .items-table td {
            border: 1px solid #ccc;
            padding: 8px 5px;
            font-size: 12px;
            text-align: center;
            vertical-align: middle;
            color: #000;
        }
        
        .items-table tr:nth-child(even) {
            background-color: #fff;
        }
        
        /* Footer */
        .footer {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: 20px;
        }
        
        .totals-block {
            width: 280px;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 700;
        }
        
        .total-line {
            border-bottom: 2px solid #000;
            margin: 5px 0;
            width: 100%;
        }
        
        .qr-block {
            text-align: center;
        }
        
        .qr-block img {
            width: 90px;
            height: 90px;
        }
        
        .site-url {
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        
    </style>
</head>
<body>
    <div class="invoice-container">
        <!-- Header -->
        <div class="header">
            <div class="company-header">
                <h1>لونج تايم للصناعات الكهربائية</h1>
                <div class="header-line"></div>
            </div>
            
            <div class="logo-container">
                ${logoBase64 ? `<img src="${logoBase64}" class="logo">` : ''}
            </div>
        </div>
        
        <!-- Meta Table -->
        <div class="meta-table-container">
            <table class="meta-table">
                <thead>
                    <tr>
                        <th>رقم الفاتورة</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>${data.invoiceNumber}</td>
                        <td>${data.date}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <!-- Customer -->
        <div class="customer-section">
            <div class="bill-to-tag">فاتورة إلى:</div>
            <div class="customer-name">السادة / ${data.customerName}</div>
            ${data.salesRepName ? `<div class="customer-sub">${data.salesRepName}</div>` : ''}
        </div>
        
        <!-- Table -->
        <table class="items-table">
            <thead>
                <tr>
                    <th>العدد في<br>الكرتونة</th>
                    <th>الإجمالي</th>
                    <th>الفئة</th>
                    <th>الكمية</th>
                    <th>الكود</th>
                    <th>اسم الصنف</th>
                    <th style="width: 30px;">م</th>
                </tr>
            </thead>
            <tbody>
                ${itemsRows}
            </tbody>
        </table>
        
        <!-- Footer -->
        <div class="footer">
            <div class="totals-block">
                <div class="total-row">
                    <span>الإجمالي</span>
                    <span>${formatNum(data.total, 2, 2)}</span>
                </div>
                <div class="total-line"></div>
                
                ${data.previousBalance ? `
                <div class="total-row">
                    <span>الرصيد السابق</span>
                    <span>${formatNum(data.previousBalance, 2, 2)}</span>
                </div>
                <div class="total-line"></div>
                ` : ''}
                
                ${data.currentBalance ? `
                <div class="total-row">
                    <span>الرصيد الحالي</span>
                    <span>${formatNum(data.currentBalance, 2, 2)}</span>
                </div>
                <div class="total-line" style="border-bottom-width: 3px;"></div>
                ` : ''}
            </div>
            
            <div class="qr-block">
                <div class="site-url">longtimelt.com</div>
                ${qrCodeBase64 ? `<img src="${qrCodeBase64}">` : ''}
            </div>
        </div>
    </div>
</body>
</html>
    `.trim();
}

/**
 * Generate PDF from HTML using browser print
 */
export async function generateInvoicePDF(data: InvoicePDFData): Promise<Blob> {
    const html = await generateInvoiceHTML(data);

    // Create hidden iframe for printing
    const iframe = document.createElement("iframe");
    iframe.style.position = "fixed";
    iframe.style.right = "-9999px";
    iframe.style.top = "-9999px";
    iframe.style.width = "210mm";
    iframe.style.height = "297mm";
    document.body.appendChild(iframe);

    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
    if (!iframeDoc) {
        document.body.removeChild(iframe);
        throw new Error("Failed to create iframe document");
    }

    iframeDoc.open();
    iframeDoc.write(html);
    iframeDoc.close();

    // Wait for images to load
    await new Promise(resolve => setTimeout(resolve, 500));

    // Use html2canvas + jsPDF for actual PDF generation
    try {
        const { default: html2canvas } = await import("html2canvas");

        const canvas = await html2canvas(iframeDoc.body, {
            scale: 2,
            useCORS: true,
            logging: false,
            backgroundColor: "#ffffff",
        });

        document.body.removeChild(iframe);

        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF({
            orientation: "portrait",
            unit: "mm",
            format: "a4",
        });

        const imgWidth = 210;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;

        pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);

        return pdf.output("blob");
    } catch (error) {
        document.body.removeChild(iframe);
        console.error("PDF generation error:", error);
        throw error;
    }
}

/**
 * Download PDF directly
 */
export async function downloadInvoicePDF(
    data: InvoicePDFData,
    filename?: string
): Promise<void> {
    const blob = await generateInvoicePDF(data);
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename || `invoice-${data.invoiceNumber}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

/**
 * Print invoice directly
 */
export async function printInvoice(data: InvoicePDFData): Promise<void> {
    const html = await generateInvoiceHTML(data);

    const printWindow = window.open("", "_blank");
    if (!printWindow) {
        throw new Error("Could not open print window");
    }

    printWindow.document.write(html);
    printWindow.document.close();

    printWindow.onload = () => {
        printWindow.print();
        setTimeout(() => printWindow.close(), 500);
    };
}

/**
 * Convert invoice from POS format to PDF format
 */
export function convertToPDFData(
    invoice: any,
    customer: any,
    items: any[],
    salesRep?: any
): InvoicePDFData {
    return {
        id: invoice.id || "",
        invoiceNumber: invoice.invoiceNumber || invoice.id || "",
        date: new Date(invoice.createdAt || Date.now()).toLocaleDateString("ar-EG"),
        customerName: customer?.name || invoice.customerName || "عميل",
        salesRepName: salesRep?.name,
        items: (items || []).map((item) => {
            const qty = item.quantity || 0;
            const price = item.price || item.unitPrice || 0;
            const total = item.total || (qty * price);
            return {
                productName: item.productName || item.name || "-",
                productCode: item.productCode || item.sku || item.barcode || "-",
                quantity: qty,
                price: price,
                total: total,
                unitsPerCarton: item.unitsPerCarton,
            };
        }),
        total: invoice.total || 0,
        previousBalance: customer?.previousBalance,
        currentBalance: customer?.currentBalance,
    };
}

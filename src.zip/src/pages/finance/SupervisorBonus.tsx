/**
 * SupervisorBonus - صفحة بونص المشرفين
 * لحساب وتطبيق البونص على المشرفين بناءً على مبيعات فريقهم
 */
import { useState, useEffect, useMemo } from "react";
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
    Award,
    DollarSign,
    Users,
    Calendar,
    TrendingUp,
    Percent,
    UserCheck
} from "lucide-react";
import { db, Supervisor, SalesRep, Invoice } from "@/shared/lib/indexedDB";
import { useSettingsContext } from "@/contexts/SettingsContext";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { POSHeader } from "@/components/POS/POSHeader";

// نوع سجل بونص المشرف
interface SupervisorBonusRecord {
    id: string;
    supervisorId: string;
    supervisorName: string;
    periodStart: string;
    periodEnd: string;
    totalTeamSales: number;
    bonusPercentage: number;
    bonusAmount: number;
    createdAt: string;
    userId: string;
    userName: string;
    notes?: string;
    salesReps: { id: string; name: string; sales: number }[];
}

const SupervisorBonus = () => {
    const { getSetting } = useSettingsContext();
    const { user } = useAuth();
    const currency = getSetting("currency") || "ج.م";

    // States
    const [supervisors, setSupervisors] = useState<Supervisor[]>([]);
    const [salesReps, setSalesReps] = useState<SalesRep[]>([]);
    const [invoices, setInvoices] = useState<Invoice[]>([]);
    const [selectedSupervisorId, setSelectedSupervisorId] = useState<string>("");
    const [dateFrom, setDateFrom] = useState<string>("");
    const [dateTo, setDateTo] = useState<string>("");
    const [bonusPercentage, setBonusPercentage] = useState<string>("5");
    const [notes, setNotes] = useState<string>("");
    const [recentBonuses, setRecentBonuses] = useState<SupervisorBonusRecord[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    // Load data on mount
    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        await db.init();
        const allSupervisors = await db.getAll<Supervisor>("supervisors");
        const activeSupervisors = allSupervisors.filter(s => s.isActive);
        setSupervisors(activeSupervisors);

        const allSalesReps = await db.getAll<SalesRep>("salesReps");
        setSalesReps(allSalesReps);

        const allInvoices = await db.getAll<Invoice>("invoices");
        setInvoices(allInvoices);

        loadRecentBonuses();
    };

    const loadRecentBonuses = () => {
        try {
            const saved = localStorage.getItem("supervisorBonuses");
            if (saved) {
                const bonuses = JSON.parse(saved) as SupervisorBonusRecord[];
                // ترتيب من الأحدث للأقدم
                setRecentBonuses(
                    bonuses.sort(
                        (a, b) =>
                            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                    )
                );
            }
        } catch (error) {
            console.error("Error loading bonuses:", error);
        }
    };

    // Get team members for selected supervisor
    const teamMembers = useMemo(() => {
        if (!selectedSupervisorId) return [];
        return salesReps.filter(rep => rep.supervisorId === selectedSupervisorId);
    }, [selectedSupervisorId, salesReps]);

    // Calculate team sales for selected period
    const teamSalesData = useMemo(() => {
        if (!selectedSupervisorId || !dateFrom || !dateTo) {
            return { total: 0, byRep: [] as { id: string; name: string; sales: number }[] };
        }

        const startDate = new Date(dateFrom);
        const endDate = new Date(dateTo + "T23:59:59");
        const teamRepIds = teamMembers.map(rep => rep.id);

        // Filter invoices by period and team members
        const periodInvoices = invoices.filter(inv => {
            const invDate = new Date(inv.createdAt);
            const isInPeriod = invDate >= startDate && invDate <= endDate;
            const isTeamInvoice = teamRepIds.includes(inv.salesRepId || "");
            return isInPeriod && isTeamInvoice;
        });

        // Calculate sales by rep
        const salesByRep: Record<string, number> = {};
        periodInvoices.forEach(inv => {
            const repId = inv.salesRepId || "";
            if (repId) {
                salesByRep[repId] = (salesByRep[repId] || 0) + (inv.total || 0);
            }
        });

        const byRep = teamMembers.map(rep => ({
            id: rep.id,
            name: rep.name,
            sales: salesByRep[rep.id] || 0,
        }));

        const total = byRep.reduce((sum, rep) => sum + rep.sales, 0);

        return { total, byRep };
    }, [selectedSupervisorId, dateFrom, dateTo, teamMembers, invoices]);

    // Calculate bonus amount
    const bonusAmount = useMemo(() => {
        const percentage = parseFloat(bonusPercentage) || 0;
        return Math.round(teamSalesData.total * (percentage / 100));
    }, [teamSalesData.total, bonusPercentage]);

    // Apply bonus
    const handleApplyBonus = async () => {
        if (!selectedSupervisorId) {
            toast.error("يرجى اختيار المشرف");
            return;
        }
        if (!dateFrom || !dateTo) {
            toast.error("يرجى تحديد الفترة");
            return;
        }
        if (teamSalesData.total <= 0) {
            toast.error("لا توجد مبيعات للفريق في هذه الفترة");
            return;
        }

        setIsLoading(true);

        try {
            const supervisor = supervisors.find(s => s.id === selectedSupervisorId);

            const newBonusRecord: SupervisorBonusRecord = {
                id: `sup_bonus_${Date.now()}`,
                supervisorId: selectedSupervisorId,
                supervisorName: supervisor?.name || "",
                periodStart: dateFrom,
                periodEnd: dateTo,
                totalTeamSales: teamSalesData.total,
                bonusPercentage: parseFloat(bonusPercentage) || 0,
                bonusAmount,
                createdAt: new Date().toISOString(),
                userId: user?.id || "",
                userName: user?.username || user?.name || "",
                notes,
                salesReps: teamSalesData.byRep,
            };

            // Save to localStorage
            const existingBonuses = JSON.parse(
                localStorage.getItem("supervisorBonuses") || "[]"
            ) as SupervisorBonusRecord[];
            existingBonuses.push(newBonusRecord);
            localStorage.setItem("supervisorBonuses", JSON.stringify(existingBonuses));

            toast.success(
                `تم تسجيل بونص ${Math.round(bonusAmount)} ${currency} للمشرف ${supervisor?.name}`
            );

            // Reset form
            setSelectedSupervisorId("");
            setDateFrom("");
            setDateTo("");
            setBonusPercentage("5");
            setNotes("");
            loadRecentBonuses();
        } catch (error) {
            toast.error("حدث خطأ أثناء تسجيل البونص");
            console.error(error);
        } finally {
            setIsLoading(false);
        }
    };

    const formatCurrency = (amount: number) => `${Math.round(amount)} ${currency}`;

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString("ar-EG");
    };

    return (
        <div className="min-h-screen bg-background" dir="rtl">
            <POSHeader />
            <div className="container mx-auto p-6 space-y-6">
                {/* Header */}
                <div className="flex items-center gap-3">
                    <Award className="h-8 w-8 text-primary" />
                    <h1 className="text-3xl font-bold">بونص المشرفين</h1>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Bonus Form */}
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <UserCheck className="h-5 w-5" />
                                حساب بونص المشرف
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {/* Supervisor Selection */}
                            <div className="space-y-2">
                                <Label>اختر المشرف</Label>
                                <Select
                                    value={selectedSupervisorId}
                                    onValueChange={setSelectedSupervisorId}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="اختر المشرف..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {supervisors.map((sup) => (
                                            <SelectItem key={sup.id} value={sup.id}>
                                                {sup.name}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            {/* Period Selection */}
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label className="flex items-center gap-2">
                                        <Calendar className="h-4 w-4" />
                                        من تاريخ
                                    </Label>
                                    <Input
                                        type="date"
                                        value={dateFrom}
                                        onChange={(e) => setDateFrom(e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label className="flex items-center gap-2">
                                        <Calendar className="h-4 w-4" />
                                        إلى تاريخ
                                    </Label>
                                    <Input
                                        type="date"
                                        value={dateTo}
                                        onChange={(e) => setDateTo(e.target.value)}
                                    />
                                </div>
                            </div>

                            {/* Team Members Display */}
                            {selectedSupervisorId && (
                                <div className="p-3 bg-muted rounded-lg">
                                    <div className="flex items-center gap-2 mb-2">
                                        <Users className="h-4 w-4" />
                                        <span className="font-semibold">فريق العمل ({teamMembers.length} مندوب)</span>
                                    </div>
                                    {teamMembers.length > 0 ? (
                                        <div className="flex flex-wrap gap-2">
                                            {teamMembers.map((rep) => (
                                                <Badge key={rep.id} variant="secondary">
                                                    {rep.name}
                                                </Badge>
                                            ))}
                                        </div>
                                    ) : (
                                        <p className="text-sm text-muted-foreground">
                                            لا يوجد مندوبين تابعين لهذا المشرف
                                        </p>
                                    )}
                                </div>
                            )}

                            {/* Sales Summary */}
                            {selectedSupervisorId && dateFrom && dateTo && (
                                <div className="space-y-3">
                                    <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-2">
                                                <TrendingUp className="h-5 w-5 text-blue-600" />
                                                <span className="font-semibold">إجمالي مبيعات الفريق</span>
                                            </div>
                                            <span className="text-2xl font-bold text-blue-600">
                                                {formatCurrency(teamSalesData.total)}
                                            </span>
                                        </div>
                                    </div>

                                    {/* Sales by Rep */}
                                    {teamSalesData.byRep.length > 0 && (
                                        <Table>
                                            <TableHeader>
                                                <TableRow>
                                                    <TableHead>المندوب</TableHead>
                                                    <TableHead className="text-left">المبيعات</TableHead>
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {teamSalesData.byRep.map((rep) => (
                                                    <TableRow key={rep.id}>
                                                        <TableCell>{rep.name}</TableCell>
                                                        <TableCell className="text-left font-medium">
                                                            {formatCurrency(rep.sales)}
                                                        </TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    )}
                                </div>
                            )}

                            {/* Bonus Percentage */}
                            <div className="space-y-2">
                                <Label className="flex items-center gap-2">
                                    <Percent className="h-4 w-4" />
                                    نسبة البونص
                                </Label>
                                <Input
                                    type="number"
                                    min="0"
                                    max="100"
                                    step="0.5"
                                    value={bonusPercentage}
                                    onChange={(e) => setBonusPercentage(e.target.value)}
                                />
                            </div>

                            {/* Bonus Amount */}
                            {teamSalesData.total > 0 && (
                                <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            <DollarSign className="h-5 w-5 text-green-600" />
                                            <span className="font-semibold">مبلغ البونص</span>
                                        </div>
                                        <span className="text-2xl font-bold text-green-600">
                                            {formatCurrency(bonusAmount)}
                                        </span>
                                    </div>
                                </div>
                            )}

                            {/* Notes */}
                            <div className="space-y-2">
                                <Label>ملاحظات (اختياري)</Label>
                                <Textarea
                                    value={notes}
                                    onChange={(e) => setNotes(e.target.value)}
                                    placeholder="أي ملاحظات إضافية..."
                                />
                            </div>

                            {/* Submit Button */}
                            <Button
                                onClick={handleApplyBonus}
                                disabled={isLoading || teamSalesData.total <= 0}
                                className="w-full"
                                size="lg"
                            >
                                <Award className="h-5 w-5 ml-2" />
                                تسجيل البونص
                            </Button>
                        </CardContent>
                    </Card>

                    {/* Recent Bonuses */}
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <DollarSign className="h-5 w-5" />
                                سجل البونص
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            {recentBonuses.length === 0 ? (
                                <div className="text-center py-8 text-muted-foreground">
                                    لا توجد سجلات بونص سابقة
                                </div>
                            ) : (
                                <div className="space-y-3 max-h-[500px] overflow-y-auto">
                                    {recentBonuses.map((bonus) => (
                                        <Card key={bonus.id} className="p-4">
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <p className="font-bold text-lg">{bonus.supervisorName}</p>
                                                    <p className="text-sm text-muted-foreground">
                                                        الفترة: {formatDate(bonus.periodStart)} - {formatDate(bonus.periodEnd)}
                                                    </p>
                                                    <p className="text-sm text-muted-foreground">
                                                        إجمالي المبيعات: {formatCurrency(bonus.totalTeamSales)}
                                                    </p>
                                                    <p className="text-sm text-muted-foreground">
                                                        المندوبين: {bonus.salesReps.map(r => r.name).join("، ")}
                                                    </p>
                                                    {bonus.notes && (
                                                        <p className="text-sm text-muted-foreground mt-1">
                                                            {bonus.notes}
                                                        </p>
                                                    )}
                                                </div>
                                                <div className="text-left">
                                                    <p className="text-xl font-bold text-green-600">
                                                        {formatCurrency(bonus.bonusAmount)}
                                                    </p>
                                                    <Badge variant="outline">{bonus.bonusPercentage}%</Badge>
                                                </div>
                                            </div>
                                        </Card>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default SupervisorBonus;
